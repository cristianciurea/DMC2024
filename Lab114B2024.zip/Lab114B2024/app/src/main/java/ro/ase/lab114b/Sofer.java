package ro.ase.lab114b;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "soferi")
public class Sofer {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String nume;
    private float salariu;

    public Sofer(String nume, float salariu) {
        this.nume = nume;
        this.salariu = salariu;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public float getSalariu() {
        return salariu;
    }

    public void setSalariu(float salariu) {
        this.salariu = salariu;
    }
}
