package ro.ase.lab114b;

import java.io.Serializable;
import java.util.Date;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "masini", foreignKeys = @ForeignKey(entity = Sofer.class,
        parentColumns = "id", childColumns = "idSofer",
        onDelete = ForeignKey.CASCADE, onUpdate = ForeignKey.CASCADE),
        indices = @Index("idSofer"))
public class Masina implements Serializable {

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    @Ignore
    private String uid;

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String marca;
    private Date dataFabricatie;
    private String culoare; //ROSU, NEGRU, ALB, GRI
    private float pret;
    private String motorizare; //BENZINA, DIESEL, HIBRID, ELECTRIC

    public int getIdSofer() {
        return idSofer;
    }

    public void setIdSofer(int idSofer) {
        this.idSofer = idSofer;
    }

    private int idSofer;

    @Ignore
    public Masina(){}

    @Ignore
    public Masina(String marca, Date dataFabricatie, String culoare, float pret, String motorizare) {
        this.marca = marca;
        this.dataFabricatie = dataFabricatie;
        this.culoare = culoare;
        this.pret = pret;
        this.motorizare = motorizare;
    }

    public Masina(String marca, Date dataFabricatie, String culoare, float pret, String motorizare, int idSofer) {
        this.marca = marca;
        this.dataFabricatie = dataFabricatie;
        this.culoare = culoare;
        this.pret = pret;
        this.motorizare = motorizare;
        this.idSofer = idSofer;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public Date getDataFabricatie() {
        return dataFabricatie;
    }

    public void setDataFabricatie(Date dataFabricatie) {
        this.dataFabricatie = dataFabricatie;
    }

    public String getCuloare() {
        return culoare;
    }

    public void setCuloare(String culoare) {
        this.culoare = culoare;
    }

    public float getPret() {
        return pret;
    }

    public void setPret(float pret) {
        this.pret = pret;
    }

    public String getMotorizare() {
        return motorizare;
    }

    public void setMotorizare(String motorizare) {
        this.motorizare = motorizare;
    }

    @Override
    public String toString() {
        return "Masina{" +
                "marca='" + marca + '\'' +
                ", dataFabricatie=" + dataFabricatie +
                ", culoare='" + culoare + '\'' +
                ", pret=" + pret +
                ", motorizare='" + motorizare + '\'' +
                '}';
    }
}
