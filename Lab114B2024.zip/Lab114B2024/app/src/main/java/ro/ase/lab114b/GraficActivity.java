/*
 package ro.ase.lab114b;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.androidplot.xy.LineAndPointFormatter;
import com.androidplot.xy.SimpleXYSeries;
import com.androidplot.xy.XYPlot;
import com.androidplot.xy.XYSeries;

import java.util.ArrayList;
import java.util.List;

 public class GraficActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grafic);

        Intent intent = getIntent();

        ArrayList<Masina> listaMasiniBenzina = (ArrayList<Masina>) intent.
                getSerializableExtra("listaMasiniBenzina");

        ArrayList<Masina> listaMasiniDiesel = (ArrayList<Masina>) intent.
                getSerializableExtra("listaMasiniDiesel");

        ArrayList<Masina> listaMasiniHibrid = (ArrayList<Masina>) intent.
                getSerializableExtra("listaMasiniHibrid");

        ArrayList<Masina> listaMasiniElectric = (ArrayList<Masina>) intent.
                getSerializableExtra("listaMasiniElectric");

        List<Double> lstPreturiBenzina = new ArrayList<>();
        List<Double> lstPreturiDiesel = new ArrayList<>();
        List<Double> lstPreturiHibrid = new ArrayList<>();
        List<Double> lstPreturiElectric = new ArrayList<>();

        for(Masina masina: listaMasiniBenzina)
            lstPreturiBenzina.add(Double.valueOf(masina.getPret()));

        for(Masina masina: listaMasiniDiesel)
            lstPreturiDiesel.add(Double.valueOf(masina.getPret()));

        for(Masina masina: listaMasiniHibrid)
            lstPreturiHibrid.add(Double.valueOf(masina.getPret()));

        for(Masina masina: listaMasiniElectric)
            lstPreturiElectric.add(Double.valueOf(masina.getPret()));

       */
/* XYPlot plot = findViewById(R.id.mySimplePlot);
        plot.setTitle("Grafic preturi masini dupa tip motorizare");

        XYSeries series1 = new SimpleXYSeries(lstPreturiBenzina,
                SimpleXYSeries.ArrayFormat.Y_VALS_ONLY,
                "BENZINA");
        plot.addSeries(series1, new LineAndPointFormatter(getApplicationContext(),
                R.layout.f1));

        XYSeries series2 = new SimpleXYSeries(lstPreturiDiesel,
                SimpleXYSeries.ArrayFormat.Y_VALS_ONLY,
                "DIESEL");
        plot.addSeries(series2, new LineAndPointFormatter(getApplicationContext(),
                R.layout.f2));

        XYSeries series3 = new SimpleXYSeries(lstPreturiHibrid,
                SimpleXYSeries.ArrayFormat.Y_VALS_ONLY,
                "HIBRID");
        plot.addSeries(series3, new LineAndPointFormatter(getApplicationContext(),
                R.layout.f3));

        XYSeries series4 = new SimpleXYSeries(lstPreturiBenzina,
                SimpleXYSeries.ArrayFormat.Y_VALS_ONLY,
                "ELECTRIC");
        plot.addSeries(series4, new LineAndPointFormatter(getApplicationContext(),
                R.layout.f4));*//*

    }
}*/
