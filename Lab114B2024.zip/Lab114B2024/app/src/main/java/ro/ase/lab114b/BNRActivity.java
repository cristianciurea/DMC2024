package ro.ase.lab114b;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

public class BNRActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bnr);

        TextView tvData = findViewById(R.id.tvData);
        EditText etEUR = findViewById(R.id.editTextEUR);
        EditText etUSD = findViewById(R.id.editTextUSD);
        EditText etGBP = findViewById(R.id.editTextGBP);
        EditText etXAU = findViewById(R.id.editTextXAU);

        TextView tvContinut = findViewById(R.id.tvContinut);

        Button btnAfisare = findViewById(R.id.btnAfisare);
        btnAfisare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //etEUR.setText("4.95");
                Network network = new Network()
                {
                    @Override
                    protected void onPostExecute(InputStream inputStream) {

                        /*Toast.makeText(getApplicationContext(),
                                Network.rezultat, Toast.LENGTH_LONG).show();*/
                        //tvContinut.setText(Network.rezultat);
                        tvData.setText(cv.getDataCurs());
                        etEUR.setText(cv.getEuro());
                        etUSD.setText(cv.getDolar());
                        etGBP.setText(cv.getLira());
                        etXAU.setText(cv.getAur());
                    }
                };
                try {
                    network.execute(new URL("https://bnro.ro/nbrfxrates.xml"));
                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        Button btnSalvare = findViewById(R.id.btnSalvare);
        btnSalvare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                CursValutar cv = new CursValutar(tvData.getText().toString(),
                        etEUR.getText().toString(),
                        etUSD.getText().toString(),
                        etGBP.getText().toString(),
                        etXAU.getText().toString());

                try {
                    scrieInFisier("fisier.dat", cv);
                    cv = null;
                    cv = citireDinFisier("fisier.dat");
                    Toast.makeText(getApplicationContext(),
                            cv.toString(), Toast.LENGTH_LONG).show();

                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

            }
        });
    }

    private void scrieInFisier(String numeFisier, CursValutar cv)
        throws IOException
    {
        FileOutputStream fisier = openFileOutput(numeFisier, Activity.MODE_PRIVATE);
        DataOutputStream dos = new DataOutputStream(fisier);
        dos.writeUTF(cv.getDataCurs());
        dos.writeUTF(cv.getEuro());
        dos.writeUTF(cv.getDolar());
        dos.writeUTF(cv.getLira());
        dos.writeUTF(cv.getAur());
        dos.flush();
        fisier.close();
    }

    private CursValutar citireDinFisier(String numeFisier) throws IOException
    {
        FileInputStream fisier = openFileInput(numeFisier);
        DataInputStream dis = new DataInputStream(fisier);
        String data = dis.readUTF();
        String euro = dis.readUTF();
        String dolar = dis.readUTF();
        String lira = dis.readUTF();
        String aur = dis.readUTF();

        CursValutar cursValutar = new CursValutar(data, euro, dolar, lira, aur);
        fisier.close();

        return cursValutar;
    }
}