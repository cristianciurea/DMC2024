package ro.ase.lab114b;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Network extends AsyncTask<URL, Void, InputStream> {

    InputStream ist = null;
    static String rezultat = "";

    @Override
    protected InputStream doInBackground(URL... urls) {

        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) urls[0].openConnection();
            conn.setRequestMethod("GET");
            ist = conn.getInputStream();

            InputStreamReader isr = new InputStreamReader(ist);
            BufferedReader br = new BufferedReader(isr);
            String linie = null;
            while ((linie = br.readLine())!=null)
                rezultat +=linie;

        } catch (IOException e) {
            e.printStackTrace();
        }

        return ist;
    }
}
