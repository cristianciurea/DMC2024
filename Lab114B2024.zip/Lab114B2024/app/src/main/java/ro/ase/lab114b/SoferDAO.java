package ro.ase.lab114b;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface SoferDAO {

    @Insert
    long insert(Sofer sofer);

    @Query("select * from soferi")
    List<Sofer> getAll();

    @Query("delete from soferi")
    void deleteAll();
}
