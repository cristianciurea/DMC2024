package ro.ase.lab114b;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

public class BNRActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bnr);

        EditText etEUR = findViewById(R.id.editTextEUR);
        TextView tvContinut = findViewById(R.id.tvContinut);

        Button btnAfisare = findViewById(R.id.btnAfisare);
        btnAfisare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //etEUR.setText("4.95");
                Network network = new Network()
                {
                    @Override
                    protected void onPostExecute(InputStream inputStream) {

                        /*Toast.makeText(getApplicationContext(),
                                Network.rezultat, Toast.LENGTH_LONG).show();*/
                        tvContinut.setText(Network.rezultat);
                    }
                };
                try {
                    network.execute(new URL("https://bnro.ro/nbrfxrates.xml"));
                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }
}