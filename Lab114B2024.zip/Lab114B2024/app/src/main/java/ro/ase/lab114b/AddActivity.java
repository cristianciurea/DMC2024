package ro.ase.lab114b;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.function.ToIntFunction;

public class AddActivity extends AppCompatActivity {//implements View.OnClickListener {

    public static final String ADD_MASINA = "addMasina";

    private FirebaseDatabase firebaseDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        Intent intent = getIntent();

        firebaseDatabase = FirebaseDatabase.getInstance();

        String[] culori = {"ROSU", "NEGRU", "ALB", "GRI"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),
                androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
                culori);
        Spinner spinnerCulori = findViewById(R.id.spinnerCuloare);
        spinnerCulori.setAdapter(adapter);

        EditText etMarca = findViewById(R.id.editTextMarca);
        EditText etData = findViewById(R.id.editTextDate);
        EditText etPret = findViewById(R.id.editTextPret);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);

        if(intent.hasExtra(MainActivity.EDIT_MASINA))
        {
            Masina masina = (Masina) intent.getSerializableExtra(MainActivity.EDIT_MASINA);
            etMarca.setText(masina.getMarca());
            etData.setText(new SimpleDateFormat("MM/dd/yyyy", Locale.US).
                    format(masina.getDataFabricatie()));
            etPret.setText(String.valueOf(masina.getPret()));
            //etPret.setText(""+masina.getPret());
            ArrayAdapter<String> adapter1 = (ArrayAdapter<String>) spinnerCulori.getAdapter();
            for(int i=0;i<adapter1.getCount();i++)
                if(adapter1.getItem(i).equals(masina.getCuloare()))
                {
                    spinnerCulori.setSelection(i);
                    break;
                }
            if(masina.getMotorizare().equals("BENZINA"))
                radioGroup.check(R.id.radioButton);
            else if(masina.getMotorizare().equals("DIESEL"))
                radioGroup.check(R.id.radioButton2);
            else
                if(masina.getMotorizare().equals("HIBRID"))
                    radioGroup.check(R.id.radioButton3);
                else radioGroup.check(R.id.radioButton4);
        }

        Button btnAdauga = findViewById(R.id.btnAdauga);
        if(intent.hasExtra(MainActivity.EDIT_MASINA))
            btnAdauga.setText("Editare masina");

        //btnAdauga.setOnClickListener(this::onClick);
        btnAdauga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etMarca.getText().toString().isEmpty())
                    etMarca.setError("Introduceti marca!");
                else
                    if(etData.getText().toString().isEmpty())
                        etData.setError("Introduceti data achizitiei!");
                    else
                        if(etPret.getText().toString().isEmpty())
                            etPret.setError("Introduceti pretul!");
                        else {
                            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
                            try {
                                sdf.parse(etData.getText().toString());
                                Date dataAchizitie = new Date(etData.getText().toString());

                                String marca = etMarca.getText().toString();
                                String culoare = spinnerCulori.getSelectedItem().toString();
                                float pret = Float.parseFloat(etPret.getText().toString());

                                RadioButton radioButton = findViewById(radioGroup.getCheckedRadioButtonId());
                                String motorizare = radioButton.getText().toString();

                                Masina masina = new Masina(marca, dataAchizitie, culoare, pret, motorizare);
                                //Toast.makeText(getApplicationContext(), masina.toString(), Toast.LENGTH_LONG).show();

                                scrieInFirebase(masina);

                                SharedPreferences spf = getSharedPreferences("masini", 0);
                                SharedPreferences.Editor editor = spf.edit();
                                editor.putString("Marca", masina.getMarca());
                                editor.putString("DataFabricatie", masina.getDataFabricatie().toString());
                                editor.putString("Culoare", masina.getCuloare());
                                editor.putFloat("Pret", masina.getPret());
                                editor.putString("Motorizare", masina.getMotorizare());
                                editor.apply();

                                intent.putExtra(ADD_MASINA, masina);
                                setResult(RESULT_OK, intent);
                                finish();

                            } catch (Exception e) {
                                e.printStackTrace();
                                Log.e("AddActivity", "Eroare data!");
                                Toast.makeText(getApplicationContext(),
                                        "Eroare data!", Toast.LENGTH_LONG).show();
                            }
                        }
            }
        });
    }

    /*@Override
    public void onClick(View view) {

    }*/

    private void scrieInFirebase(Masina masina)
    {
        DatabaseReference myRef = firebaseDatabase.getReference("sem114b2024-default-rtdb");
        myRef.keepSynced(true);

        myRef.child("sem114b2024-default-rtdb").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                masina.setUid(myRef.child("sem114b2024-default-rtdb").push().getKey());
                myRef.child("sem114b2024-default-rtdb").
                        child(masina.getUid()).setValue(masina);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}