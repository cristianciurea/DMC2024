package ro.ase.lab114b;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BarChartActivity extends AppCompatActivity {

    ArrayList<Masina> list;
    LinearLayout layout;
    Map<String, Integer> source;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bar_chart);

        Intent intent = getIntent();
        list = (ArrayList<Masina>) intent.getSerializableExtra("list");

        source = getSource(list);

        layout = findViewById(R.id.layoutBar);
        layout.addView(new BarChartView(getApplicationContext(), source));
    }

    private Map<String, Integer> getSource(List<Masina> masinaList)
    {
        if(masinaList==null || masinaList.isEmpty())
            return new HashMap<>();
        else {
            Map<String, Integer> results = new HashMap<>();
            for(Masina masina: masinaList)
                if(results.containsKey(masina.getMarca()))
                    results.put(masina.getMarca(),
                            results.get(masina.getMarca())+1);
            else
                    results.put(masina.getMarca(), 1);
            return results;
        }
    }
}